# Fake-Currency-Detection-using-DIP
I created a website which checks the features of the Indian notes and predicts whether a the note is fake or original; based on the features matching. If all the features are matching then the note is original else fake
